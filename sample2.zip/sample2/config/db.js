// 데이터베이스 연결정보. module.exports의 선언으로 외부에서 이 데이터 정보를 사용할 수 있다.
module.exports = {
    host : 'localhost',
    user : 'nodejs',
    password : 'nodejs',
    database : 'study'
}